import mongoose from "mongoose";

const multiplayerRoomSchema = new mongoose.Schema({
  roomKey: { type: String, required: true, unique: true }, // 6-digit unique room key
  hostID: { type: mongoose.Schema.Types.ObjectId, ref: "Player", required: true },
  players: [{ type: mongoose.Schema.Types.ObjectId, ref: "Player" }], // All players in the room
  gameSettings: { 
    numRounds: { type: Number, required: true },
    timePerRound: { type: Number, required: true }
  },
  status: { type: String, enum: ["waiting", "inProgress", "finished"], default: "waiting" }
});

export default mongoose.model("MultiplayerRoom", multiplayerRoomSchema);
