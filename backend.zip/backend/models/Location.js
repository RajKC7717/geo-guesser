import mongoose from "mongoose";

const locationSchema = new mongoose.Schema({
  locationID: { type: String, required: true, unique: true }, // Unique ID for each location
  gameID: { type: String, required: true }, // Game session this location belongs to
  coordinates: { type: { lat: Number, lng: Number }, required: true },
  imageUrl: { type: String, required: true }, // Street view image URL
});

export default mongoose.model("Location", locationSchema);
