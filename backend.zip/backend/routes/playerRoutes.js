import express from "express";
import Player from "../models/Player.js"; 
import bcrypt from "bcryptjs"; // For password hashing
import jwt from "jsonwebtoken"; // For generating authentication tokens
import dotenv from "dotenv";

dotenv.config();

const router = express.Router();

// Register a new player
router.post("/register", async (req, res) => {
  try {
    const { email, name, ign, age, password } = req.body;

    // Check if user already exists
    const existingPlayer = await Player.findOne({ email });
    if (existingPlayer) {
      return res.status(400).json({ message: "Email already in use" });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create new player
    const newPlayer = new Player({
      email,
      name,
      ign,
      age,
      password: hashedPassword,
    });

    await newPlayer.save();
    res.status(201).json({ message: "Player registered successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// Login player
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check if player exists
    const player = await Player.findOne({ email });
    if (!player) {
      return res.status(400).json({ message: "Invalid email or password" });
    }

    // Check password
    const isMatch = await bcrypt.compare(password, player.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid email or password" });
    }

    // Generate token
    const token = jwt.sign({ id: player._id }, process.env.JWT_SECRET, { expiresIn: "1h" });

    res.status(200).json({ token, playerId: player._id, ign: player.ign });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// Route for guest login
router.get("/guest", (req, res) => {
    const randomNum = Math.floor(1000 + Math.random() * 9000); // Generate 4-digit number
    const guestID = `Guest#${randomNum}`;
    
    res.status(200).json({ guestID });
  });
  
export default router;
